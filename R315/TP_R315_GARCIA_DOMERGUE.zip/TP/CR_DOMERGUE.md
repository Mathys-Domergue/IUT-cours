# Compte rendu
### Mathys DOMERUGE
## Thibault Garcia
### RT2

## <center> TP 





### Project libre



Pour voir l'emploie du temps de l'entrepris ele fichier du GANTT se situe dans le dossier.



1) Calcule des salaires

 - Ingénieur numéro 1 :

    Calcule d'heure effectuer par l'ingénieur:

    - Jours tot = 23 jours
    - Heure tot = $\frac{23}{35}$ = 184
    - Semaine 1 = $H_{étape1} + H_{étape3}$ = 41 heures
    - Semaine 2 = $H_{étape3}$ = 46 heures
    - Semaine 3 = $H_{étape3} + H_{étape4}$ = 47 heures
    - Semaine 4 = $H_{étape4} + H_{étape5}$ = 46 heures
    - Semaine 5 = $H_{étape5}$ = 40 heures

    Heure normale = 21,74 €
    Majoré 25 % = 27.175 €
    Majoré 50 % = 32.61 €



    Semaine 1 = 35 + (6 $\times$ 1,25) = 760,9 + 163,05 = 923,95€
    Semaine 2 = 35 + (8 $\times$ 1,25) + (3 $\times$ 1,5) = 1076,13€
    Semaine 3 = 35 + (8 $\times$ 1,25) + (4 $\times$ 1,5) = 1108,74€
    Semaine 4 = 35 + (8 $\times$ 1,25) + (3 $\times$ 1,5) =1076,13€
    Semaine 5 = 35 + (3 $\times$ 1,25)=896,77€


    Coût Total = Salire Ingénieur 1+ Salaire Ingénieur 2 + Frais Hébergement = 5081.72 + 3000 + 4250 = 12 331,72€

